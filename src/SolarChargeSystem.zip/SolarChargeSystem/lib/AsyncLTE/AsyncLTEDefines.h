#ifndef __ASYNCLTEDEFINES_H__
#define __ASYNCLTEDEFINES_H__

#include <Arduino.h>


// #define ASYNCLTE_OK F("OK");
// #define ASYNCLTE_ERROR F("ERROR");

// enum class AsyncLTEResultType  {OK,ERROR,}




#endif // __ASYNCLTEDEFINES_H__