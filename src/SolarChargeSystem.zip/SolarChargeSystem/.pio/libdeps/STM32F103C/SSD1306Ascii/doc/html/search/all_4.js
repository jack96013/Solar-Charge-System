var searchData=
[
  ['endcol',['endCol',['../struct_ticker_state.html#ade980baf5a975237a3a8212985081beb',1,'TickerState']]]
];
